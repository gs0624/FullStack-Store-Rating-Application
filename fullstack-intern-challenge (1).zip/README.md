# FullStack Store Rating App

## Tech: React, Express, PostgreSQL, JWT, RBAC