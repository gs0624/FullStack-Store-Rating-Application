const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize(process.env.DATABASE_URL, { dialect: 'postgres' });

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.User = require('./user')(sequelize, DataTypes);
db.Store = require('./store')(sequelize, DataTypes);
db.Rating = require('./rating')(sequelize, DataTypes);

db.User.hasMany(db.Rating);
db.Store.hasMany(db.Rating);
db.Rating.belongsTo(db.User);
db.Rating.belongsTo(db.Store);

module.exports = db;