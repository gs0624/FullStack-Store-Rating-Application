module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Rating', {
    value: DataTypes.INTEGER
  });
};