const router = require('express').Router();
// Register, Login, Update Password endpoints go here
module.exports = router;