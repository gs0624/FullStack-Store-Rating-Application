const router = require('express').Router();
// Store list, rating APIs go here
module.exports = router;