const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const db = require('./models');
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/stores', require('./routes/stores'));

db.sequelize.sync().then(() => {
  app.listen(5000, () => console.log('Server started'));
});