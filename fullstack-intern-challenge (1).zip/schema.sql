
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  address VARCHAR(400),
  role VARCHAR(20)
);
CREATE TABLE stores (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  address VARCHAR(400)
);
CREATE TABLE ratings (
  id SERIAL PRIMARY KEY,
  value INTEGER,
  user_id INTEGER REFERENCES users(id),
  store_id INTEGER REFERENCES stores(id)
);